module.exports = {
  OWNER_ID: [1234567],
  TELEGRAM_TOKEN: "TOKEN",
  PORT: 3000,
};
